# Changelog

## 1.1.10
- Backup and restore for all tables: export and share, import with preview (new/updated/unchanged), Merge or Replace, automatic daily local backup (last 7), share reminder, open backups from WhatsApp or files. `appVersion`, `author`, upgrades hook.
- Monthly tab renamed Expense.
- Expense years page: year-by-year bars, all-years numbers (savings rate, average spending, best year, highest spending year).
- Year page: averages, year forecast, biggest expenses, categories vs last year, spending by weekday, spending by account.
- Overview per-year cards: comparison with the previous year.
- No database change. Unit tests for version compare, merge, backup format, yearly stats.

## 1.0.14
- Month page: comparison with the previous month, end-of-month forecast (current month), day-by-day spending bars with average per day and biggest expenses, category breakdown with change vs last month.
- Year page: comparison with the previous year, balance curve with best and worst month.
- Pure logic in `CashStats` with unit tests. No database change.

## 1.0.13
- Overview statistics: net worth over time, your money vs growth, savings runway, passive income (interest + dividends), stock performance with dividend yield, concentration warning.
- Pure logic in `OverviewStats` with unit tests. No database change.

## 1.0.12
- Monthly tab now opens on a years page. Tap a year for its statistics (totals, income/expense bars per month, savings rate, average spending, spending by category, each month). Tap a month for the month page.
- Month page gets a back button when opened this way. No database change.
- Unit test for year/month totals.

## 1.0.11
- New look: navy/blue/gray/white palette, rounder shapes, navy gradient hero cards with a faint peak shape.
- Custom outline icons (drawn with Canvas) replace emoji in navigation, headers, buttons and history rows. Icon tiles on lists.
- Launcher icon recolored: navy background, sky-blue bars.
- Dynamic colors now default to off (turn on in Settings).

## 1.0.1
- New concept: savings tracker. Bottom navigation: Overview, Banks, Stocks, Monthly.
- Bank accounts (current and savings with yearly rate): deposits, withdrawals, interest, balance chart, history, interest by year.
- Stock accounts: stocks, buys, sells, fees, dividends, average cost, profit/loss, history.
- Overview: net worth, allocation, gains and per-year stats of everything combined.
- Room schema v2 with migration 1 to 2 (monthly data kept). Unit tests for position math.

## 1.0.0
- First version: transactions, accounts, categories, monthly totals.
- Settings (currency, theme, dynamic colors), About with copyright and links.
- Peak-A adaptive icon with monochrome layer.
- Room schema v1 with exportSchema, unit test for money parsing.
