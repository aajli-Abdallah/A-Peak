# A-Peak v1.1.10

Personal savings and finance tracker for Android. Offline first, no account. By AAJLI Abdallah.

## Stack
Kotlin, Jetpack Compose (Material 3), Room + KSP (schema v2, migration 1 to 2), one ViewModel, StateFlows. minSdk 26, applicationId `com.aajli.apeak`.

## Tabs
- **Overview**: net worth, allocation, gains, details, then: net worth over time (stocks at cost), your money vs growth, savings runway, passive income, stock performance, concentration, per-year stats.
- **Banks**: any number of current or savings accounts. Log deposits, withdrawals, yearly interest. Balance chart, history, interest by year, expected yearly interest.
- **Stocks**: any number of stock accounts. Add stocks, log buys, sells, fees, dividends. Average cost, market value, profit/loss, history.
- **Expense** (was Monthly): years page (all-time totals, one card per year) > year page (balance, bars per month, vs previous year, balance curve with best/worst month, savings rate, spending by category, 12 month rows) > month page (vs last month, end-of-month forecast, day-by-day bars, biggest expenses, category breakdown with change, then the transactions with undo).
- Settings: currency, theme, dynamic colors, About.

## Backup and restore
Settings > Backup: export and share (JSON, `A-Peak-backup-DATE.json`), import file, automatic daily copy on the phone (last 7, in app storage, lost on uninstall, so share one). Opening a backup from WhatsApp or a file manager starts the import preview. Overview shows a reminder after 14 days without sharing.
- File: `app`, `formatVersion`, `appVersion` (missing = 1.0.0), `author`, `exportedAt`, `settings`, one array per table. Ordered `Upgrades` hook in `BackupCodec.kt`. A backup from a newer app version is refused.
- Preview shows new / updated / unchanged per table. **Merge**: match by id, then by name (accounts, categories, banks, stock accounts, stocks by account+symbol); same id with different content = backup wins; children are re-pointed to the matched parent. Settings untouched. **Replace**: saves a safety copy, wipes all tables, restores everything including settings.

## Design
Navy, blue, gray and white palette (light and dark). Custom outline icons drawn in code (`ui/Icons.kt`), navy gradient hero cards, rounded tiles. Dynamic colors are OFF by default so the brand palette shows; switch on in Settings. Category and account icons are still user-chosen emoji.

## Rules
- Amounts are `Long` minor units (cents), prices too (2 decimals). Quantities are `Double`. UUID string ids.
- Stock cost uses the average-cost method. Fees raise cost on buys and reduce proceeds on sells.
- Market value uses the **last price you enter** per stock (no internet, no price feed).
- Single currency for the whole app.
- All UI text in `strings.xml`. Version from `BuildConfig`. Commit `app/schemas/`.

## Known limits
- Deleting a bank or stock account deletes its history (asks confirmation first).
- Status bar icon colour follows the system theme, not the in-app override.
- No Gradle wrapper jar: open in Android Studio and sync.

## Roadmap
1.1 backup/restore (all tables), 1.2 budgets, 1.3 statistics charts over time + tests, 1.4 recurring, 1.5 transfers, 1.6 search/CSV, 1.7 goals, 1.8 receipts, 1.9 lock + widget, 2.0 release.
