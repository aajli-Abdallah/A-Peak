package com.aajli.apeak.ui

import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aajli.apeak.MainViewModel
import com.aajli.apeak.R
import kotlinx.coroutines.launch

private suspend fun shareBackup(ctx: Context, vm: MainViewModel) {
    val uri = vm.backups.shareUri()
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "application/json"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(send, null))
    vm.settings.markShared()
}

private fun tableLabel(key: String) = when (key) {
    "accounts" -> R.string.tbl_accounts
    "categories" -> R.string.tbl_categories
    "transactions" -> R.string.tbl_transactions
    "bank_accounts" -> R.string.tbl_bank_accounts
    "bank_entries" -> R.string.tbl_bank_entries
    "broker_accounts" -> R.string.tbl_brokers
    "stocks" -> R.string.tbl_stocks
    "trades" -> R.string.tbl_trades
    else -> R.string.tbl_dividends
}

/** Settings card: share, import, automatic backups. */
@Composable
fun BackupSection(vm: MainViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val last by vm.settings.lastShared.collectAsState()
    val files = remember { vm.backups.autoFiles() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.prepareImportFromUri(uri) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.backup_title), style = MaterialTheme.typography.titleMedium)
            Text(stringResource(R.string.backup_hint), style = MaterialTheme.typography.bodySmall)
            Text(if (last == 0L) stringResource(R.string.backup_last_never) else stringResource(R.string.backup_last, fmtDate(last)),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = { scope.launch { shareBackup(ctx, vm) } }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(stringResource(R.string.backup_share))
            }
            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.backup_import))
            }
            if (files.isNotEmpty()) {
                Text(stringResource(R.string.backup_auto_title), style = MaterialTheme.typography.labelLarge)
                files.forEach { f ->
                    TextButton(onClick = { vm.prepareImportFromFile(f) }, modifier = Modifier.fillMaxWidth()) {
                        Text(f.name.removePrefix("apeak-auto-").removeSuffix(".json"))
                    }
                }
            }
        }
    }
}

/** Banner on the Overview when no backup was shared for 14 days (or ever). */
@Composable
fun BackupReminder(vm: MainViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val last by vm.settings.lastShared.collectAsState()
    val after by vm.settings.remindAfter.collectAsState()
    val all by vm.allTransactions.collectAsState()
    val banks by vm.banks.collectAsState()
    val brokers by vm.brokers.collectAsState()
    val now = System.currentTimeMillis()
    val hasData = all.isNotEmpty() || banks.isNotEmpty() || brokers.isNotEmpty()
    val days = if (last == 0L) null else (now - last) / 86_400_000L
    val due = hasData && now >= after && (days == null || days >= 14)
    if (due) Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (days == null) stringResource(R.string.reminder_never) else stringResource(R.string.reminder_days, days.toInt()))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { scope.launch { shareBackup(ctx, vm) } }) { Text(stringResource(R.string.reminder_share)) }
                TextButton(onClick = { vm.settings.snooze() }) { Text(stringResource(R.string.reminder_later)) }
            }
        }
    }
}

/** Import preview and error dialogs. Lives at the app root so a file opened from WhatsApp works from any screen. */
@Composable
fun ImportHost(vm: MainViewModel) {
    val preview by vm.importPreview.collectAsState()
    val error by vm.importError.collectAsState()
    var confirmReplace by remember { mutableStateOf(false) }
    error?.let { res ->
        AlertDialog(
            onDismissRequest = { vm.importError.value = null },
            title = { Text(stringResource(R.string.import_title)) },
            text = { Text(stringResource(res)) },
            confirmButton = { TextButton(onClick = { vm.importError.value = null }) { Text(stringResource(R.string.ok)) } }
        )
    }
    preview?.let { p ->
        AlertDialog(
            onDismissRequest = { vm.cancelImport() },
            title = { Text(stringResource(R.string.import_preview)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(stringResource(R.string.import_from, p.data.appVersion, p.data.recordCount), style = MaterialTheme.typography.bodySmall)
                    p.merge.report.filter { it.new + it.updated + it.unchanged > 0 }.forEach { r ->
                        KeyVal(stringResource(tableLabel(r.key)), stringResource(R.string.import_counts, r.new, r.updated, r.unchanged))
                    }
                    Text(stringResource(R.string.import_replace_note, p.currentCount, p.data.recordCount), style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
                }
            },
            confirmButton = { TextButton(onClick = { vm.confirmImport(false) }) { Text(stringResource(R.string.import_merge)) } },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmReplace = true }) { Text(stringResource(R.string.import_replace), color = MaterialTheme.colorScheme.error) }
                    TextButton(onClick = { vm.cancelImport() }) { Text(stringResource(R.string.cancel)) }
                }
            }
        )
        if (confirmReplace) AlertDialog(
            onDismissRequest = { confirmReplace = false },
            title = { Text(stringResource(R.string.import_replace)) },
            text = { Text(stringResource(R.string.import_replace_confirm)) },
            confirmButton = { TextButton(onClick = { confirmReplace = false; vm.confirmImport(true) }) { Text(stringResource(R.string.import_replace), color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmReplace = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
