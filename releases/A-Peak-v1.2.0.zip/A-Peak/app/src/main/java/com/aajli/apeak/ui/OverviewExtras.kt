package com.aajli.apeak.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aajli.apeak.MainViewModel
import com.aajli.apeak.R
import com.aajli.apeak.data.BankType
import com.aajli.apeak.util.Calc
import com.aajli.apeak.util.Money
import com.aajli.apeak.util.NetPoint
import com.aajli.apeak.util.OverviewStats
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale

private fun label(p: NetPoint) =
    "${p.month.month.getDisplayName(java.time.format.TextStyle.SHORT, Locale.getDefault())} ${p.month.year}"

@Composable
fun StatCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

/** Extra statistics shown on the Overview page (1.0.13). */
@Composable
fun OverviewExtras(vm: MainViewModel) {
    val banks by vm.banks.collectAsState()
    val entries by vm.bankEntries.collectAsState()
    val brokers by vm.brokers.collectAsState()
    val stocks by vm.stocks.collectAsState()
    val trades by vm.trades.collectAsState()
    val divs by vm.dividends.collectAsState()
    val txs by vm.allTransactions.collectAsState()
    val cur by vm.settings.currency.collectAsState()
    val today = LocalDate.now()
    val byAcc = entries.groupBy { it.accountId }
    val rows = stocks.map { Calc.stockRow(it, trades, divs) }
    val balances = banks.map { it to Calc.bankBalance(it, byAcc[it.id].orEmpty()) }
    val liquid = balances.sumOf { it.second }
    val stockValue = rows.sumOf { it.valueMinor }
    val net = liquid + stockValue

    // O1 net worth over time (stocks at cost)
    val series = remember(banks, entries, trades) { OverviewStats.netWorthSeries(banks, entries, trades) }
    if (series.size >= 2) StatCard(stringResource(R.string.nw_title)) {
        LineChart(series.map { it.value })
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label(series.first()), style = MaterialTheme.typography.bodySmall)
            Text(label(series.last()), style = MaterialTheme.typography.bodySmall)
        }
        Text(stringResource(R.string.nw_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }

    // O2 own money vs growth
    val contributions = banks.sumOf { it.openingMinor } +
        entries.filter { it.type == BankType.DEPOSIT }.sumOf { it.amountMinor } -
        entries.filter { it.type == BankType.WITHDRAW }.sumOf { it.amountMinor } +
        rows.sumOf { it.pos.costMinor - it.pos.realizedMinor }
    val growth = net - contributions
    if (net != 0L || contributions != 0L) StatCard(stringResource(R.string.contrib_title)) {
        KeyVal(stringResource(R.string.contributions), Money.format(contributions, cur))
        KeyVal(stringResource(R.string.growth), signed(growth, cur), gainColor(growth))
        if (contributions > 0) KeyVal(stringResource(R.string.growth_pct), "%+.1f%%".format(growth * 100.0 / contributions), gainColor(growth))
        StackedBar(listOf(stringResource(R.string.contributions) to contributions, stringResource(R.string.growth) to growth), cur)
    }

    // O6 savings runway
    val avgSpend = OverviewStats.avgMonthlySpending(txs, today)
    if (avgSpend > 0 && liquid > 0) StatCard(stringResource(R.string.runway_title)) {
        Text(stringResource(R.string.runway_fmt, "%.1f".format(liquid.toDouble() / avgSpend)),
            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        KeyVal(stringResource(R.string.runway_liquid), Money.format(liquid, cur))
        KeyVal(stringResource(R.string.avg_expense), Money.format(avgSpend, cur))
    }

    // O3 passive income
    val passive = entries.filter { it.type == BankType.INTEREST }.map { it.dateMillis to it.amountMinor } +
        divs.map { it.dateMillis to it.amountMinor }
    if (passive.isNotEmpty()) {
        val total = passive.sumOf { it.second }
        val cutoff = dayStart(today.minusMonths(12))
        val span = (ChronoUnit.MONTHS.between(toDate(passive.minOf { it.first }), today) + 1).coerceAtLeast(1L)
        StatCard(stringResource(R.string.passive_title)) {
            KeyVal(stringResource(R.string.passive_total), Money.format(total, cur), incomeColor())
            KeyVal(stringResource(R.string.passive_year), Money.format(passive.filter { toDate(it.first).year == today.year }.sumOf { it.second }, cur))
            KeyVal(stringResource(R.string.passive_12m), Money.format(passive.filter { it.first >= cutoff }.sumOf { it.second }, cur))
            KeyVal(stringResource(R.string.passive_avg), Money.format(total / span, cur))
        }
    }

    // O4 return per stock
    val perf = rows.filter { it.pos.boughtMinor > 0 }.sortedByDescending { it.totalReturn.toDouble() / it.pos.boughtMinor }
    if (perf.isNotEmpty()) StatCard(stringResource(R.string.perf_title)) {
        Text(stringResource(R.string.perf_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        perf.take(8).forEach { r ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(r.stock.symbol, fontWeight = FontWeight.SemiBold)
                    if (r.pos.costMinor > 0 && r.dividendsMinor > 0)
                        Text(stringResource(R.string.yield_fmt, "%.1f%%".format(r.dividendsMinor * 100.0 / r.pos.costMinor)), style = MaterialTheme.typography.bodySmall)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("%+.1f%%".format(r.totalReturn * 100.0 / r.pos.boughtMinor), color = gainColor(r.totalReturn), fontWeight = FontWeight.SemiBold)
                    Text(signed(r.totalReturn, cur), style = MaterialTheme.typography.bodySmall, color = gainColor(r.totalReturn))
                }
            }
        }
    }

    // O5 concentration
    val parts = (balances.map { it.first.name to it.second } +
        brokers.map { b -> b.name to rows.filter { it.stock.accountId == b.id }.sumOf { it.valueMinor } }).filter { it.second > 0 }
    if (parts.isNotEmpty()) StatCard(stringResource(R.string.conc_title)) {
        StackedBar(parts, cur)
        val top = rows.maxByOrNull { it.valueMinor }
        if (top != null && stockValue > 0) {
            val share = top.valueMinor * 100 / stockValue
            if (share > 30) Text(stringResource(R.string.conc_warn, top.stock.symbol, share.toInt()), color = MaterialTheme.colorScheme.error)
        }
    }
}
