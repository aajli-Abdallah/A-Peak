package com.aajli.apeak.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Currency
import java.util.Locale

object Tx {
    const val INCOME = "INCOME"
    const val EXPENSE = "EXPENSE"
}

@Entity(tableName = "accounts")
data class AccountEntity(@PrimaryKey val id: String, val name: String, val icon: String, val sortOrder: Int)

@Entity(tableName = "categories")
data class CategoryEntity(@PrimaryKey val id: String, val name: String, val icon: String, val type: String, val sortOrder: Int)

/** Each transaction keeps a snapshot of the account and category name/icon. */
@Entity(tableName = "transactions", indices = [Index("dateMillis")])
data class TransactionEntity(
    @PrimaryKey val id: String,
    val type: String,
    val amountMinor: Long,
    val dateMillis: Long,
    val note: String,
    val accountId: String,
    val accountName: String,
    val accountIcon: String,
    val categoryId: String,
    val categoryName: String,
    val categoryIcon: String,
    val createdAt: Long
)

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts ORDER BY sortOrder, name") fun observeAll(): Flow<List<AccountEntity>>
    @Upsert suspend fun upsert(item: AccountEntity)
    @Upsert suspend fun upsertAll(items: List<AccountEntity>)
    @Query("DELETE FROM accounts WHERE id = :id") suspend fun deleteById(id: String)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY sortOrder, name") fun observeAll(): Flow<List<CategoryEntity>>
    @Upsert suspend fun upsert(item: CategoryEntity)
    @Upsert suspend fun upsertAll(items: List<CategoryEntity>)
    @Query("DELETE FROM categories WHERE id = :id") suspend fun deleteById(id: String)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE dateMillis >= :fromMillis AND dateMillis < :toMillis ORDER BY dateMillis DESC, createdAt DESC")
    fun observeBetween(fromMillis: Long, toMillis: Long): Flow<List<TransactionEntity>>
    @Upsert suspend fun upsert(item: TransactionEntity)
    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC") fun observeAll(): Flow<List<TransactionEntity>>
    @Delete suspend fun delete(item: TransactionEntity)
}

@Database(entities = [AccountEntity::class, CategoryEntity::class, TransactionEntity::class, BankAccountEntity::class, BankEntryEntity::class, BrokerAccountEntity::class, StockEntity::class, StockTradeEntity::class, DividendEntity::class], version = 2, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun accounts(): AccountDao
    abstract fun categories(): CategoryDao
    abstract fun transactions(): TransactionDao
    abstract fun wealth(): WealthDao

    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "apeak.db")
                .addMigrations(MIGRATION_1_2).build().also { inst = it }
        }
    }
}

class SettingsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("apeak_settings", Context.MODE_PRIVATE)
    private val _currency = MutableStateFlow(p.getString("currency", null) ?: defaultCurrency())
    private val _theme = MutableStateFlow(p.getString("theme", "SYSTEM") ?: "SYSTEM")
    private val _dynamic = MutableStateFlow(p.getBoolean("dynamic", false))
    val currency: StateFlow<String> = _currency
    val theme: StateFlow<String> = _theme
    val dynamic: StateFlow<Boolean> = _dynamic

    fun setCurrency(v: String) { p.edit().putString("currency", v).apply(); _currency.value = v }
    fun setTheme(v: String) { p.edit().putString("theme", v).apply(); _theme.value = v }
    fun setDynamic(v: Boolean) { p.edit().putBoolean("dynamic", v).apply(); _dynamic.value = v }
    var seeded: Boolean
        get() = p.getBoolean("seeded", false)
        set(v) { p.edit().putBoolean("seeded", v).apply() }

    private fun defaultCurrency() = try { Currency.getInstance(Locale.getDefault()).currencyCode } catch (e: Exception) { "USD" }
}

// ---------------- Version 1.0.1: banks, savings, stock accounts ----------------
object BankKind { const val CURRENT = "CURRENT"; const val SAVINGS = "SAVINGS" }
object BankType { const val DEPOSIT = "DEPOSIT"; const val WITHDRAW = "WITHDRAW"; const val INTEREST = "INTEREST" }
object TradeType { const val BUY = "BUY"; const val SELL = "SELL" }

@Entity(tableName = "bank_accounts")
data class BankAccountEntity(
    @PrimaryKey val id: String, val name: String, val bankName: String, val kind: String,
    val interestRate: Double, val openingMinor: Long, val note: String, val createdAt: Long
)

@Entity(tableName = "bank_entries", indices = [Index("accountId")])
data class BankEntryEntity(
    @PrimaryKey val id: String, val accountId: String, val type: String,
    val amountMinor: Long, val dateMillis: Long, val note: String
)

@Entity(tableName = "broker_accounts")
data class BrokerAccountEntity(
    @PrimaryKey val id: String, val name: String, val brokerName: String, val note: String, val createdAt: Long
)

@Entity(tableName = "stocks", indices = [Index("accountId")])
data class StockEntity(
    @PrimaryKey val id: String, val accountId: String, val symbol: String, val name: String,
    val lastPriceMinor: Long, val lastPriceDate: Long, val createdAt: Long
)

@Entity(tableName = "stock_trades", indices = [Index("stockId")])
data class StockTradeEntity(
    @PrimaryKey val id: String, val stockId: String, val type: String, val quantity: Double,
    val priceMinor: Long, val feesMinor: Long, val dateMillis: Long, val note: String
)

@Entity(tableName = "dividends", indices = [Index("stockId")])
data class DividendEntity(
    @PrimaryKey val id: String, val stockId: String, val amountMinor: Long, val dateMillis: Long, val note: String
)

@Dao
interface WealthDao {
    @Query("SELECT * FROM bank_accounts ORDER BY createdAt") fun banks(): Flow<List<BankAccountEntity>>
    @Query("SELECT * FROM bank_entries ORDER BY dateMillis DESC") fun bankEntries(): Flow<List<BankEntryEntity>>
    @Query("SELECT * FROM broker_accounts ORDER BY createdAt") fun brokers(): Flow<List<BrokerAccountEntity>>
    @Query("SELECT * FROM stocks ORDER BY symbol") fun stocks(): Flow<List<StockEntity>>
    @Query("SELECT * FROM stock_trades ORDER BY dateMillis DESC") fun trades(): Flow<List<StockTradeEntity>>
    @Query("SELECT * FROM dividends ORDER BY dateMillis DESC") fun dividends(): Flow<List<DividendEntity>>

    @Upsert suspend fun upsertBank(item: BankAccountEntity)
    @Upsert suspend fun upsertBankEntry(item: BankEntryEntity)
    @Upsert suspend fun upsertBroker(item: BrokerAccountEntity)
    @Upsert suspend fun upsertStock(item: StockEntity)
    @Upsert suspend fun upsertTrade(item: StockTradeEntity)
    @Upsert suspend fun upsertDividend(item: DividendEntity)

    @Query("DELETE FROM bank_accounts WHERE id = :id") suspend fun deleteBank(id: String)
    @Query("DELETE FROM bank_entries WHERE accountId = :id") suspend fun deleteBankEntriesOf(id: String)
    @Query("DELETE FROM bank_entries WHERE id = :id") suspend fun deleteBankEntry(id: String)
    @Query("DELETE FROM broker_accounts WHERE id = :id") suspend fun deleteBroker(id: String)
    @Query("SELECT id FROM stocks WHERE accountId = :id") suspend fun stockIdsOf(id: String): List<String>
    @Query("DELETE FROM stocks WHERE id = :id") suspend fun deleteStock(id: String)
    @Query("DELETE FROM stock_trades WHERE stockId = :id") suspend fun deleteTradesOfStock(id: String)
    @Query("DELETE FROM dividends WHERE stockId = :id") suspend fun deleteDividendsOfStock(id: String)
    @Query("DELETE FROM stock_trades WHERE id = :id") suspend fun deleteTrade(id: String)
    @Query("DELETE FROM dividends WHERE id = :id") suspend fun deleteDividend(id: String)
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        listOf(
            "CREATE TABLE IF NOT EXISTS `bank_accounts` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `bankName` TEXT NOT NULL, `kind` TEXT NOT NULL, `interestRate` REAL NOT NULL, `openingMinor` INTEGER NOT NULL, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`id`))",
            "CREATE TABLE IF NOT EXISTS `bank_entries` (`id` TEXT NOT NULL, `accountId` TEXT NOT NULL, `type` TEXT NOT NULL, `amountMinor` INTEGER NOT NULL, `dateMillis` INTEGER NOT NULL, `note` TEXT NOT NULL, PRIMARY KEY(`id`))",
            "CREATE INDEX IF NOT EXISTS `index_bank_entries_accountId` ON `bank_entries` (`accountId`)",
            "CREATE TABLE IF NOT EXISTS `broker_accounts` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `brokerName` TEXT NOT NULL, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`id`))",
            "CREATE TABLE IF NOT EXISTS `stocks` (`id` TEXT NOT NULL, `accountId` TEXT NOT NULL, `symbol` TEXT NOT NULL, `name` TEXT NOT NULL, `lastPriceMinor` INTEGER NOT NULL, `lastPriceDate` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`id`))",
            "CREATE INDEX IF NOT EXISTS `index_stocks_accountId` ON `stocks` (`accountId`)",
            "CREATE TABLE IF NOT EXISTS `stock_trades` (`id` TEXT NOT NULL, `stockId` TEXT NOT NULL, `type` TEXT NOT NULL, `quantity` REAL NOT NULL, `priceMinor` INTEGER NOT NULL, `feesMinor` INTEGER NOT NULL, `dateMillis` INTEGER NOT NULL, `note` TEXT NOT NULL, PRIMARY KEY(`id`))",
            "CREATE INDEX IF NOT EXISTS `index_stock_trades_stockId` ON `stock_trades` (`stockId`)",
            "CREATE TABLE IF NOT EXISTS `dividends` (`id` TEXT NOT NULL, `stockId` TEXT NOT NULL, `amountMinor` INTEGER NOT NULL, `dateMillis` INTEGER NOT NULL, `note` TEXT NOT NULL, PRIMARY KEY(`id`))",
            "CREATE INDEX IF NOT EXISTS `index_dividends_stockId` ON `dividends` (`stockId`)"
        ).forEach { db.execSQL(it) }
    }
}
