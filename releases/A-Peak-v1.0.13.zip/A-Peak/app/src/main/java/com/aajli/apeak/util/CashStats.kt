package com.aajli.apeak.util

import com.aajli.apeak.data.TransactionEntity
import com.aajli.apeak.data.Tx
import java.time.Instant
import java.time.ZoneId

data class MonthTotals(val income: Long, val expense: Long) {
    val balance: Long get() = income - expense
}

object CashStats {
    private fun zdt(ms: Long) = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())

    fun totals(txs: List<TransactionEntity>) = MonthTotals(
        txs.filter { it.type == Tx.INCOME }.sumOf { it.amountMinor },
        txs.filter { it.type == Tx.EXPENSE }.sumOf { it.amountMinor }
    )

    /** Years with data, newest first. */
    fun byYear(txs: List<TransactionEntity>): Map<Int, MonthTotals> =
        txs.groupBy { zdt(it.dateMillis).year }.mapValues { totals(it.value) }.toSortedMap(reverseOrder())

    /** Always 12 entries, January to December. */
    fun byMonth(txs: List<TransactionEntity>, year: Int): List<MonthTotals> {
        val g = txs.filter { zdt(it.dateMillis).year == year }.groupBy { zdt(it.dateMillis).monthValue }
        return (1..12).map { totals(g[it].orEmpty()) }
    }

    fun spendingByCategory(txs: List<TransactionEntity>, year: Int): List<Pair<String, Long>> =
        txs.filter { it.type == Tx.EXPENSE && zdt(it.dateMillis).year == year }
            .groupBy { it.categoryName }.map { it.key to it.value.sumOf { t -> t.amountMinor } }
            .sortedByDescending { it.second }
}
