package com.aajli.apeak

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aajli.apeak.data.*
import androidx.room.withTransaction
import android.net.Uri
import com.aajli.apeak.backup.*
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.YearMonth
import java.time.ZoneId
import java.util.UUID

private fun uid() = UUID.randomUUID().toString()

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    val settings = SettingsStore(app)
    val backups = BackupManager(app, db, settings)
    val month = MutableStateFlow(YearMonth.now())
    val lastDeleted = MutableStateFlow<TransactionEntity?>(null)

    val accounts = db.accounts().observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val categories = db.categories().observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val transactions = month.flatMapLatest { m ->
        val z = ZoneId.systemDefault()
        db.transactions().observeBetween(
            m.atDay(1).atStartOfDay(z).toInstant().toEpochMilli(),
            m.plusMonths(1).atDay(1).atStartOfDay(z).toInstant().toEpochMilli()
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init { io { seedIfNeeded(); backups.autoDaily() } }

    private fun io(block: suspend () -> Unit) { viewModelScope.launch(Dispatchers.IO) { block() } }

    private suspend fun seedIfNeeded() {
        if (settings.seeded) return
        val a = getApplication<Application>()
        fun s(id: Int) = a.getString(id)
        db.accounts().upsertAll(listOf(
            AccountEntity(uid(), s(R.string.acc_cash), "💵", 0),
            AccountEntity(uid(), s(R.string.acc_bank), "🏦", 1),
            AccountEntity(uid(), s(R.string.acc_card), "💳", 2)
        ))
        val exp = listOf(R.string.cat_food to "🍽️", R.string.cat_transport to "🚌", R.string.cat_home to "🏠",
            R.string.cat_bills to "💡", R.string.cat_health to "💊", R.string.cat_shopping to "🛍️",
            R.string.cat_fun to "🎬", R.string.cat_other to "📦")
        val inc = listOf(R.string.cat_salary to "💼", R.string.cat_gift to "🎁", R.string.cat_other_income to "💰")
        db.categories().upsertAll(
            exp.mapIndexed { i, c -> CategoryEntity(uid(), s(c.first), c.second, Tx.EXPENSE, i) } +
            inc.mapIndexed { i, c -> CategoryEntity(uid(), s(c.first), c.second, Tx.INCOME, i) }
        )
        settings.seeded = true
    }

    fun saveTransaction(existing: TransactionEntity?, type: String, amountMinor: Long, date: Long,
                        note: String, acc: AccountEntity, cat: CategoryEntity) = io {
        db.transactions().upsert(TransactionEntity(
            existing?.id ?: uid(), type, amountMinor, date, note,
            acc.id, acc.name, acc.icon, cat.id, cat.name, cat.icon,
            existing?.createdAt ?: System.currentTimeMillis()
        ))
    }

    fun deleteTransaction(t: TransactionEntity) { lastDeleted.value = t; io { db.transactions().delete(t) } }
    fun undoDelete() { val t = lastDeleted.value ?: return; lastDeleted.value = null; io { db.transactions().upsert(t) } }
    fun clearDeleted() { lastDeleted.value = null }

    fun saveAccount(id: String, name: String, icon: String) = io {
        val cur = accounts.value
        val order = cur.find { it.id == id }?.sortOrder ?: cur.size
        db.accounts().upsert(AccountEntity(id.ifEmpty { uid() }, name, icon, order))
    }
    fun deleteAccount(id: String) = io { db.accounts().deleteById(id) }

    fun saveCategory(id: String, name: String, icon: String, type: String, updatePast: Boolean = false) = io {
        val cur = categories.value
        val order = cur.find { it.id == id }?.sortOrder ?: cur.count { it.type == type }
        db.categories().upsert(CategoryEntity(id.ifEmpty { uid() }, name, icon, type, order))
        if (updatePast && id.isNotEmpty()) db.transactions().renameCategory(id, name, icon)
    }
    fun deleteCategory(id: String) = io { db.categories().deleteById(id) }

    // ---- Wealth: banks, savings, stock accounts ----
    val allTransactions = db.transactions().observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    private val w = db.wealth()
    val banks = w.banks().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val bankEntries = w.bankEntries().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val brokers = w.brokers().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val stocks = w.stocks().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val trades = w.trades().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val dividends = w.dividends().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun saveBank(item: BankAccountEntity) = io { w.upsertBank(item) }
    fun deleteBank(id: String) = io { db.withTransaction { w.deleteBankEntriesOf(id); w.deleteBank(id) } }
    fun saveBankEntry(item: BankEntryEntity) = io { w.upsertBankEntry(item) }
    fun deleteBankEntry(id: String) = io { w.deleteBankEntry(id) }
    fun saveBroker(item: BrokerAccountEntity) = io { w.upsertBroker(item) }
    fun deleteBroker(id: String) = io {
        db.withTransaction {
            w.stockIdsOf(id).forEach { s -> w.deleteTradesOfStock(s); w.deleteDividendsOfStock(s); w.deleteStock(s) }
            w.deleteBroker(id)
        }
    }
    fun saveStock(item: StockEntity) = io { w.upsertStock(item) }
    fun deleteStock(id: String) = io { db.withTransaction { w.deleteTradesOfStock(id); w.deleteDividendsOfStock(id); w.deleteStock(id) } }
    fun saveTrade(t: StockTradeEntity) = io {
        w.upsertTrade(t)
        val s = stocks.value.find { it.id == t.stockId }
        if (s != null && s.lastPriceMinor == 0L) w.upsertStock(s.copy(lastPriceMinor = t.priceMinor, lastPriceDate = t.dateMillis))
    }
    fun deleteTrade(id: String) = io { w.deleteTrade(id) }
    fun saveDividend(item: DividendEntity) = io { w.upsertDividend(item) }
    fun deleteDividend(id: String) = io { w.deleteDividend(id) }

    // ---- Backup / import ----
    val importPreview = MutableStateFlow<ImportPreview?>(null)
    val importError = MutableStateFlow<Int?>(null)

    fun prepareImportFromUri(uri: Uri) = io {
        val text = try {
            getApplication<Application>().contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
        } catch (e: Exception) { null }
        if (text == null) { importError.value = R.string.import_invalid } else { prepareImport(text, uri.lastPathSegment ?: "") }
    }

    fun prepareImportFromFile(f: File) = io { prepareImport(f.readText(), f.name) }

    private suspend fun prepareImport(text: String, source: String) {
        try {
            val data = BackupCodec.decode(text)
            if (Versions.compare(data.appVersion, BuildConfig.VERSION_NAME) > 0) { importError.value = R.string.import_newer; return }
            val cur = backups.snapshot()
            importPreview.value = ImportPreview(data, BackupMerge.merge(cur, data), source, cur.recordCount)
        } catch (e: Exception) { importError.value = R.string.import_invalid }
    }

    fun confirmImport(replace: Boolean) = io {
        val p = importPreview.value ?: return@io
        importPreview.value = null
        backups.apply(p, replace)
    }

    fun cancelImport() { importPreview.value = null }
}
