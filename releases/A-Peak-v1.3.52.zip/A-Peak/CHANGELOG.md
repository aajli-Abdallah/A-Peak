# Changelog

## 1.3.52
- Dividends screen (Stocks tab > Dividends): last 12 months total, monthly bars, projected yearly dividends, yield on cost and on current value, totals by year and by stock.
- Faster dividend entry: type the dividend per share and the total is filled from the shares held on that date (override allowed).
- No database change. Unit tests for dividend statistics.

## 1.3.51
- Portfolio value vs money invested chart over time: all stocks (Holdings tab) and per account (account page).
- Merge the same ticker across accounts into one line. Weight of each holding in the portfolio.
- Portfolio stats: open holdings, best and worst performer, total fees paid.
- No database change. Unit tests for merging, best/worst and the portfolio series.

## 1.3.50
- Stocks tab: Update prices screen (all held stocks at once, previous price, % change, age badge) and a banner when prices are 7+ days old.
- Stocks tab: Holdings list across all accounts with sorting (value, return, A-Z) and a switch to hide closed positions.
- No database change. Unit tests for holdings and sorting.

## 1.3.0
- Category trend chart on the Year page: spending per month stacked by category (top 5 + other).
- Price history (new table): net worth over time now uses recorded stock prices, and each stock page has a price chart.
- Room schema v4, migration 3 to 4 (backfills history from existing trades and last prices). Price history included in backups.
- Unit tests for category trend, price history, net worth with prices, and backup of prices.
- Already delivered earlier and not rebuilt: spending by category, monthly trend, balance curve, net worth chart.

## 1.2.0
- Monthly budgets per category with progress bars (amber from 80%, red from 100%) and alerts when saving an expense reaches 80% or 100%.
- Budgets screen (set, change, remove; month navigation), budget card on the month page, budget summary and alerts on the Expense tab.
- Limits are versioned by month, so past months keep their old limit.
- Room schema v3 with migration 2 to 3. Budgets included in backups (old backups still import). Unit tests for budget logic.

## 1.1.11
- Add from a month page now starts the calendar in that month (today if it is the current month).
- Expense tab: totals per category for each year (expense and income, all categories listed), a categories-by-year table across years, and a shortcut to add, rename or delete categories.
- Renaming a category can update past transactions too.
- No database schema change. Unit tests for category totals.

## 1.1.10
- Backup and restore for all tables: export and share, import with preview (new/updated/unchanged), Merge or Replace, automatic daily local backup (last 7), share reminder, open backups from WhatsApp or files. `appVersion`, `author`, upgrades hook.
- Monthly tab renamed Expense.
- Expense years page: year-by-year bars, all-years numbers (savings rate, average spending, best year, highest spending year).
- Year page: averages, year forecast, biggest expenses, categories vs last year, spending by weekday, spending by account.
- Overview per-year cards: comparison with the previous year.
- No database change. Unit tests for version compare, merge, backup format, yearly stats.

## 1.0.14
- Month page: comparison with the previous month, end-of-month forecast (current month), day-by-day spending bars with average per day and biggest expenses, category breakdown with change vs last month.
- Year page: comparison with the previous year, balance curve with best and worst month.
- Pure logic in `CashStats` with unit tests. No database change.

## 1.0.13
- Overview statistics: net worth over time, your money vs growth, savings runway, passive income (interest + dividends), stock performance with dividend yield, concentration warning.
- Pure logic in `OverviewStats` with unit tests. No database change.

## 1.0.12
- Monthly tab now opens on a years page. Tap a year for its statistics (totals, income/expense bars per month, savings rate, average spending, spending by category, each month). Tap a month for the month page.
- Month page gets a back button when opened this way. No database change.
- Unit test for year/month totals.

## 1.0.11
- New look: navy/blue/gray/white palette, rounder shapes, navy gradient hero cards with a faint peak shape.
- Custom outline icons (drawn with Canvas) replace emoji in navigation, headers, buttons and history rows. Icon tiles on lists.
- Launcher icon recolored: navy background, sky-blue bars.
- Dynamic colors now default to off (turn on in Settings).

## 1.0.1
- New concept: savings tracker. Bottom navigation: Overview, Banks, Stocks, Monthly.
- Bank accounts (current and savings with yearly rate): deposits, withdrawals, interest, balance chart, history, interest by year.
- Stock accounts: stocks, buys, sells, fees, dividends, average cost, profit/loss, history.
- Overview: net worth, allocation, gains and per-year stats of everything combined.
- Room schema v2 with migration 1 to 2 (monthly data kept). Unit tests for position math.

## 1.0.0
- First version: transactions, accounts, categories, monthly totals.
- Settings (currency, theme, dynamic colors), About with copyright and links.
- Peak-A adaptive icon with monochrome layer.
- Room schema v1 with exportSchema, unit test for money parsing.
