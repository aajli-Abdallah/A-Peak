package com.aajli.apeak

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.aajli.apeak.data.TransactionEntity
import com.aajli.apeak.ui.*

sealed interface Screen {
    data class Tab(val i: Int) : Screen
    data class Form(val tx: TransactionEntity?) : Screen
    data object Settings : Screen
    data object Manage : Screen
    data class BankDetail(val id: String) : Screen
    data class BrokerDetail(val id: String) : Screen
    data class StockDetail(val id: String) : Screen
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val theme by vm.settings.theme.collectAsState()
            val dynamic by vm.settings.dynamic.collectAsState()
            APeakTheme(theme, dynamic) { AppRoot(vm) }
        }
    }
}

@Composable
fun AppRoot(vm: MainViewModel) {
    val stack = remember { mutableStateListOf<Screen>(Screen.Tab(0)) }
    fun push(s: Screen) { stack.add(s) }
    fun pop() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    BackHandler(enabled = stack.size > 1) { pop() }
    val tabs = listOf(Ico.Overview to R.string.nav_overview, Ico.Bank to R.string.nav_banks, Ico.Stocks to R.string.nav_stocks, Ico.Calendar to R.string.nav_monthly)
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when (val s = stack.last()) {
            is Screen.Tab -> Scaffold(
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    NavigationBar {
                        tabs.forEachIndexed { i, (icon, label) ->
                            NavigationBarItem(
                                selected = s.i == i,
                                onClick = { stack.clear(); stack.add(Screen.Tab(i)) },
                                icon = { AppIcon(icon) },
                                label = { Text(stringResource(label)) }
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad)) {
                    when (s.i) {
                        0 -> OverviewScreen(vm) { push(Screen.Settings) }
                        1 -> BanksScreen(vm) { push(Screen.BankDetail(it)) }
                        2 -> BrokersScreen(vm) { push(Screen.BrokerDetail(it)) }
                        else -> HomeScreen(vm, { push(Screen.Form(null)) }, { push(Screen.Form(it)) }, { push(Screen.Settings) })
                    }
                }
            }
            is Screen.Form -> TransactionForm(vm, s.tx) { pop() }
            Screen.Settings -> SettingsScreen(vm, { pop() }, { push(Screen.Manage) })
            Screen.Manage -> ManageScreen(vm) { pop() }
            is Screen.BankDetail -> BankDetail(vm, s.id) { pop() }
            is Screen.BrokerDetail -> BrokerDetail(vm, s.id, { pop() }, { push(Screen.StockDetail(it)) })
            is Screen.StockDetail -> StockDetail(vm, s.id) { pop() }
        }
    }
}
