package com.aajli.apeak.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightScheme = lightColorScheme(
    primary = Color(0xFF0F766E), onPrimary = Color.White,
    primaryContainer = Color(0xFFCCFBF1), onPrimaryContainer = Color(0xFF042F2E),
    tertiary = Color(0xFFF59E0B)
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF5EEAD4), onPrimary = Color(0xFF042F2E),
    primaryContainer = Color(0xFF0F4C47), onPrimaryContainer = Color(0xFFCCFBF1),
    tertiary = Color(0xFFFBBF24)
)

val LocalIsDark = staticCompositionLocalOf { false }
@Composable fun incomeColor() = if (LocalIsDark.current) Color(0xFF81C784) else Color(0xFF2E7D32)
@Composable fun expenseColor() = if (LocalIsDark.current) Color(0xFFE57373) else Color(0xFFC62828)

@Composable
fun APeakTheme(theme: String, dynamic: Boolean, content: @Composable () -> Unit) {
    val dark = when (theme) { "LIGHT" -> false; "DARK" -> true; else -> isSystemInDarkTheme() }
    val ctx = LocalContext.current
    val scheme = if (dynamic && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else if (dark) DarkScheme else LightScheme
    CompositionLocalProvider(LocalIsDark provides dark) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
