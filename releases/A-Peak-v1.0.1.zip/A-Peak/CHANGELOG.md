# Changelog

## 1.0.1
- New concept: savings tracker. Bottom navigation: Overview, Banks, Stocks, Monthly.
- Bank accounts (current and savings with yearly rate): deposits, withdrawals, interest, balance chart, history, interest by year.
- Stock accounts: stocks, buys, sells, fees, dividends, average cost, profit/loss, history.
- Overview: net worth, allocation, gains and per-year stats of everything combined.
- Room schema v2 with migration 1 to 2 (monthly data kept). Unit tests for position math.

## 1.0.0
- First version: transactions, accounts, categories, monthly totals.
- Settings (currency, theme, dynamic colors), About with copyright and links.
- Peak-A adaptive icon with monochrome layer.
- Room schema v1 with exportSchema, unit test for money parsing.
