package com.aajli.apeak.util

import kotlin.math.roundToLong

/** One line of the holdings list: a single stock, or all stocks with the same ticker when merged. */
data class Holding(
    val key: String, val symbol: String, val name: String,
    val accounts: List<String>, val stockIds: List<String>,
    val qty: Double, val costMinor: Long, val valueMinor: Long,
    val realizedMinor: Long, val dividendsMinor: Long, val boughtMinor: Long
) {
    val unrealizedMinor: Long get() = if (qty > 0) valueMinor - costMinor else 0L
    val totalReturn: Long get() = unrealizedMinor + realizedMinor + dividendsMinor
    val returnPct: Double? get() = if (boughtMinor > 0) totalReturn * 100.0 / boughtMinor else null
    val avgPrice: Long get() = if (qty > 0) (costMinor.toDouble() / qty).roundToLong() else 0L
}

object StockAnalytics {
    fun holdings(rows: List<StockRow>, accountName: (String) -> String, merge: Boolean): List<Holding> {
        fun one(r: StockRow) = Holding(r.stock.id, r.stock.symbol, r.stock.name, listOf(accountName(r.stock.accountId)), listOf(r.stock.id),
            r.pos.qty, r.pos.costMinor, r.valueMinor, r.pos.realizedMinor, r.dividendsMinor, r.pos.boughtMinor)
        if (!merge) return rows.map { one(it) }
        return rows.groupBy { it.stock.symbol.uppercase() }.map { (sym, list) ->
            val hs = list.map { one(it) }
            Holding(sym, sym, hs.firstOrNull { it.name.isNotBlank() }?.name ?: "", hs.flatMap { it.accounts }.distinct(), hs.flatMap { it.stockIds },
                hs.sumOf { it.qty }, hs.sumOf { it.costMinor }, hs.sumOf { it.valueMinor }, hs.sumOf { it.realizedMinor },
                hs.sumOf { it.dividendsMinor }, hs.sumOf { it.boughtMinor })
        }
    }

    /** mode 0 = value, 1 = return %, 2 = symbol. */
    fun sort(h: List<Holding>, mode: Int): List<Holding> = when (mode) {
        1 -> h.sortedByDescending { it.returnPct ?: Double.NEGATIVE_INFINITY }
        2 -> h.sortedBy { it.symbol }
        else -> h.sortedByDescending { it.valueMinor }
    }

    fun ageDays(lastPriceDate: Long, now: Long = System.currentTimeMillis()): Int = ((now - lastPriceDate) / 86_400_000L).toInt()
}
