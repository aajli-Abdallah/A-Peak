# A-Peak v1.3.50

Personal savings and finance tracker for Android. Offline first, no account. By AAJLI Abdallah.

## Stack
Kotlin, Jetpack Compose (Material 3), Room + KSP (schema v2, migration 1 to 2), one ViewModel, StateFlows. minSdk 26, applicationId `com.aajli.apeak`.

## Tabs
- **Overview**: net worth, allocation, gains, details, then: net worth over time (stocks at recorded prices), your money vs growth, savings runway, passive income, stock performance, concentration, per-year stats.
- **Banks**: any number of current or savings accounts. Log deposits, withdrawals, yearly interest. Balance chart, history, interest by year, expected yearly interest.
- **Stocks**: any number of stock accounts. Add stocks, log buys, sells, fees, dividends. Average cost, market value, profit/loss, history.
- **Expense** (was Monthly): years page (all-time totals, one card per year) > year page (balance, bars per month, vs previous year, balance curve with best/worst month, savings rate, spending by category, 12 month rows) > month page (vs last month, end-of-month forecast, day-by-day bars, biggest expenses, category breakdown with change, then the transactions with undo).
- Settings: currency, theme, dynamic colors, About.

## Stocks tab
- Update prices: one screen for all held stocks, oldest first, with % change; stale prices (7+ days) trigger a banner.
- Holdings: every stock across accounts, sorted by value, return or name, closed positions hidden by default.

## Price history
Every price you enter for a stock, and every trade price, is saved as a point (one per stock per day). The net worth chart uses the latest recorded price before each month end (cost if none) and each stock page shows its price chart. The migration 3 to 4 fills the history from your existing trades and last prices. Points are evenly spaced on the chart. Part of backups.

## Budgets
A monthly limit per expense category (Expense tab > Budgets, or from a month page). Bars turn amber at 80% and red at 100%. Saving an expense that reaches 80% or 100% shows an alert. The Expense tab shows this month's budgets and alerts first. Limits are versioned by month: a change applies from the month shown onward and earlier months keep their old limit; 0 removes the budget from that month. Spending is matched by category id, so renaming keeps the budget. Budgets are part of backups (Room schema v3, migration 2 to 3). No system notifications yet.

## Categories
Expense tab shows every category (also with 0) with its total per year, expense and income, and a table of all years. "Add, rename or delete categories" opens Manage on the Expense tab. Renaming offers "Also update past transactions" (on by default). Deleting keeps old transactions under their saved name. New transactions from a month page start in that month.

## Backup and restore
Settings > Backup: export and share (JSON, `A-Peak-backup-DATE.json`), import file, automatic daily copy on the phone (last 7, in app storage, lost on uninstall, so share one). Opening a backup from WhatsApp or a file manager starts the import preview. Overview shows a reminder after 14 days without sharing.
- File: `app`, `formatVersion`, `appVersion` (missing = 1.0.0), `author`, `exportedAt`, `settings`, one array per table. Ordered `Upgrades` hook in `BackupCodec.kt`. A backup from a newer app version is refused.
- Preview shows new / updated / unchanged per table. **Merge**: match by id, then by name (accounts, categories, banks, stock accounts, stocks by account+symbol); same id with different content = backup wins; children are re-pointed to the matched parent. Settings untouched. **Replace**: saves a safety copy, wipes all tables, restores everything including settings.

## Design
Navy, blue, gray and white palette (light and dark). Custom outline icons drawn in code (`ui/Icons.kt`), navy gradient hero cards, rounded tiles. Dynamic colors are OFF by default so the brand palette shows; switch on in Settings. Category and account icons are still user-chosen emoji.

## Rules
- Amounts are `Long` minor units (cents), prices too (2 decimals). Quantities are `Double`. UUID string ids.
- Stock cost uses the average-cost method. Fees raise cost on buys and reduce proceeds on sells.
- Market value uses the **last price you enter** per stock (no internet, no price feed).
- Single currency for the whole app.
- All UI text in `strings.xml`. Version from `BuildConfig`. Commit `app/schemas/`.

## Known limits
- Deleting a bank or stock account deletes its history (asks confirmation first).
- Status bar icon colour follows the system theme, not the in-app override.
- No Gradle wrapper jar: open in Android Studio and sync.

## Roadmap
1.1 backup/restore (all tables), 1.2 budgets, 1.3 statistics charts over time + tests, 1.4 recurring, 1.5 transfers, 1.6 search/CSV, 1.7 goals, 1.8 receipts, 1.9 lock + widget, 2.0 release.
