package com.aajli.apeak.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aajli.apeak.MainViewModel
import com.aajli.apeak.R
import com.aajli.apeak.util.Calc
import com.aajli.apeak.util.Holding
import com.aajli.apeak.util.Money
import com.aajli.apeak.util.StockAnalytics

@Composable
private fun HoldingCard(h: Holding, portfolio: Long, cur: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(enabled = h.stockIds.size == 1, onClick = onClick)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconTile(Ico.Stocks)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(h.symbol, style = MaterialTheme.typography.titleMedium)
                val detail = if (h.qty > 0) "${Money.qtyInput(h.qty)} × ${Money.format(h.avgPrice, cur)}" else stringResource(R.string.closed)
                Text(listOf(h.accounts.joinToString(", "), detail).filter { it.isNotBlank() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (h.qty > 0 && portfolio > 0) Text(stringResource(R.string.weight_fmt, "%.1f".format(h.valueMinor * 100.0 / portfolio)), style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(Money.format(h.valueMinor, cur), fontWeight = FontWeight.SemiBold)
                Text(signed(h.totalReturn, cur) + (h.returnPct?.let { "  (%+.1f%%)".format(it) } ?: ""),
                    style = MaterialTheme.typography.bodySmall, color = gainColor(h.totalReturn))
            }
        }
    }
}

/** Stocks tab: accounts, and a holdings list across all accounts. */
@Composable
fun BrokersScreen(vm: MainViewModel, onOpen: (String) -> Unit, onOpenStock: (String) -> Unit = {}, onPrices: () -> Unit = {}) {
    val brokers by vm.brokers.collectAsState()
    val stocks by vm.stocks.collectAsState()
    val trades by vm.trades.collectAsState()
    val divs by vm.dividends.collectAsState()
    val cur by vm.settings.currency.collectAsState()
    var adding by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var sort by remember { mutableIntStateOf(0) }
    var hideClosed by remember { mutableStateOf(true) }
    var merge by remember { mutableStateOf(false) }
    val rows = stocks.map { Calc.stockRow(it, trades, divs) }
    val stale = rows.count { it.pos.qty > 0 && (it.stock.lastPriceMinor == 0L || StockAnalytics.ageDays(it.stock.lastPriceDate) >= 7) }
    val nameOf = { id: String -> brokers.find { it.id == id }?.name ?: "" }
    val all = StockAnalytics.holdings(rows, nameOf, merge)
    val holdings = StockAnalytics.sort(all.filter { !hideClosed || it.qty > 0 }, sort)
    val portfolioValue = rows.sumOf { it.valueMinor }
    Scaffold(
        contentWindowInsets = WindowInsets.statusBars,
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { adding = true }) { Text(stringResource(R.string.add_broker_fab)) } }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.nav_stocks), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 8.dp))
            HeroCard {
                Column(Modifier.padding(16.dp)) {
                    Text(stringResource(R.string.stocks_value), style = MaterialTheme.typography.labelMedium)
                    Text(Money.format(portfolioValue, cur), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    val tr = rows.sumOf { it.totalReturn }
                    KeyVal(stringResource(R.string.total_return), signed(tr, cur), gainColor(tr))
                }
            }
            if (stocks.isNotEmpty()) {
                if (stale > 0) Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.prices_stale, stale))
                        Button(onClick = onPrices) { Text(stringResource(R.string.update_prices)) }
                    }
                } else OutlinedButton(onClick = onPrices, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.update_prices)) }
                // MARK:buttons
            }
            ToggleRow(listOf(stringResource(R.string.tab_accounts), stringResource(R.string.tab_holdings)), tab) { tab = it }
            if (tab == 1) {
                ToggleRow(listOf(stringResource(R.string.sort_value), stringResource(R.string.sort_return), stringResource(R.string.sort_name)), sort) { sort = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = hideClosed, onCheckedChange = { hideClosed = it })
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.hide_closed))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = merge, onCheckedChange = { merge = it })
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.merge_ticker))
                }
            }
            LazyColumn(contentPadding = PaddingValues(bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (tab == 0) {
                    if (brokers.isEmpty()) item { Text(stringResource(R.string.no_brokers)) }
                    items(brokers, key = { it.id }) { b ->
                        val mine = rows.filter { it.stock.accountId == b.id }
                        Card(Modifier.fillMaxWidth().clickable { onOpen(b.id) }) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                IconTile(Ico.Overview)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(b.name, style = MaterialTheme.typography.titleMedium)
                                    Text(b.brokerName, style = MaterialTheme.typography.bodySmall)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(Money.format(mine.sumOf { it.valueMinor }, cur), fontWeight = FontWeight.SemiBold)
                                    val tr = mine.sumOf { it.totalReturn }
                                    Text(signed(tr, cur), style = MaterialTheme.typography.bodySmall, color = gainColor(tr))
                                }
                            }
                        }
                    }
                } else {
                    item { PortfolioChartCard(vm, null) }
                    item { PortfolioStatsCard(all, trades.sumOf { it.feesMinor }, cur) }
                    if (holdings.isEmpty()) item { Text(stringResource(R.string.no_holdings)) }
                    items(holdings, key = { it.key }) { h -> HoldingCard(h, portfolioValue, cur) { h.stockIds.singleOrNull()?.let(onOpenStock) } }
                }
            }
        }
    }
    if (adding) BrokerDialog(vm, null) { adding = false }
}
