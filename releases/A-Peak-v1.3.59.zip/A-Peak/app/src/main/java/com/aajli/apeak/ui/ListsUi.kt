package com.aajli.apeak.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aajli.apeak.MainViewModel
import com.aajli.apeak.StocksViewModel
import com.aajli.apeak.R
import com.aajli.apeak.data.LookupItemEntity
import com.aajli.apeak.data.LookupKind
import com.aajli.apeak.data.SecurityEntity
import com.aajli.apeak.util.newId

/** A picker with an extra last entry to add a new item. */
@Composable
fun PickOrAdd(label: String, value: String, options: List<String>, addLabel: String, onPick: (Int) -> Unit, onAdd: () -> Unit) {
    PickerField(label, value.ifBlank { stringResource(R.string.pick_hint) }, options + addLabel) { i -> if (i >= options.size) onAdd() else onPick(i) }
}

@Composable
fun AddNameDialog(title: String, label: String, initial: String = "", onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    var err by remember { mutableStateOf(false) }
    FormDialog(title, onDismiss, onSave = { if (text.isBlank()) err = true else onSave(text.trim()) }) {
        TextF(label, text) { text = it }
        if (err) Text(stringResource(R.string.check_values), color = MaterialTheme.colorScheme.error)
    }
}

/** Add or edit a stock of the stock list. onSaved gets the saved item (an existing one if the symbol is already listed). */
@Composable
fun SecurityDialog(vm: StocksViewModel, existing: SecurityEntity?, onSaved: (SecurityEntity) -> Unit = {}, onDismiss: () -> Unit) {
    val secs by vm.securities.collectAsState()
    var symbol by remember { mutableStateOf(existing?.symbol ?: "") }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var err by remember { mutableStateOf(false) }
    FormDialog(stringResource(if (existing == null) R.string.new_security else R.string.edit_security), onDismiss, onSave = {
        val sym = symbol.trim().uppercase()
        if (sym.isEmpty()) err = true
        else {
            val dup = secs.find { it.symbol.equals(sym, true) && it.id != existing?.id }
            val item = if (dup != null) dup.copy(name = name.trim().ifBlank { dup.name }) else SecurityEntity(existing?.id ?: newId(), sym, name.trim())
            vm.saveSecurity(item)
            onSaved(item)
            onDismiss()
        }
    }) {
        TextF(stringResource(R.string.symbol), symbol) { symbol = it }
        TextF(stringResource(R.string.stock_name), name) { name = it }
        if (err) Text(stringResource(R.string.check_values), color = MaterialTheme.colorScheme.error)
    }
}

/** Manage the lists behind the pickers: brokers, account names, stocks. */
@Composable
fun ListsScreen(vm: StocksViewModel, startTab: Int, onBack: () -> Unit) {
    val lookups by vm.lookups.collectAsState()
    val secs by vm.securities.collectAsState()
    var tab by remember { mutableIntStateOf(startTab) }
    var newLookup by remember { mutableStateOf(false) }
    var editingLookup by remember { mutableStateOf<LookupItemEntity?>(null) }
    var newSec by remember { mutableStateOf(false) }
    var editingSec by remember { mutableStateOf<SecurityEntity?>(null) }
    val kind = if (tab == 0) LookupKind.BROKER else LookupKind.ACCOUNT
    val dialogTitle = stringResource(if (tab == 0) R.string.add_broker_name else R.string.add_account_name)
    val dialogLabel = stringResource(if (tab == 0) R.string.broker_company else R.string.account_name)
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(stringResource(R.string.lists_title), onBack)
        ToggleRow(listOf(stringResource(R.string.list_brokers), stringResource(R.string.list_accounts), stringResource(R.string.list_stocks)), tab) { tab = it }
        Text(stringResource(R.string.lists_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(Modifier.weight(1f)) {
            if (tab < 2) items(lookups.filter { it.kind == kind }, key = { it.id }) { l ->
                Row(Modifier.fillMaxWidth().clickable { editingLookup = l }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(l.name, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    IconBtn(Ico.Close, { vm.deleteLookup(l.id) }, MaterialTheme.colorScheme.error)
                }
            } else items(secs, key = { it.id }) { s ->
                Row(Modifier.fillMaxWidth().clickable { editingSec = s }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.symbol, fontWeight = FontWeight.SemiBold)
                        Text(s.name, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconBtn(Ico.Close, { vm.deleteSecurity(s.id) }, MaterialTheme.colorScheme.error)
                }
            }
        }
        Button(onClick = { if (tab < 2) newLookup = true else newSec = true }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text(stringResource(R.string.list_add))
        }
        Spacer(Modifier.height(8.dp))
    }
    if (newLookup) AddNameDialog(dialogTitle, dialogLabel, onDismiss = { newLookup = false }) { n -> vm.addLookup(kind, n); newLookup = false }
    editingLookup?.let { l -> AddNameDialog(dialogTitle, dialogLabel, l.name, { editingLookup = null }) { n -> vm.renameLookup(l, n); editingLookup = null } }
    if (newSec) SecurityDialog(vm, null) { newSec = false }
    editingSec?.let { s -> SecurityDialog(vm, s) { editingSec = null } }
}
