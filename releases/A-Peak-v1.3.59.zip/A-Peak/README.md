# A-Peak v1.3.59

Personal savings and finance tracker for Android. Offline first, no account. By AAJLI Abdallah.

## Stack
Kotlin, Jetpack Compose (Material 3), Room + KSP (schema v2, migration 1 to 2), one ViewModel, StateFlows. minSdk 26, applicationId `com.aajli.apeak`.

## Tabs
- **Overview**: net worth, allocation, gains, details, then: net worth over time (stocks at recorded prices), your money vs growth, savings runway, passive income, stock performance, concentration, per-year stats.
- **Banks**: any number of current or savings accounts. Log deposits, withdrawals, yearly interest. Balance chart, history, interest by year, expected yearly interest.
- **Stocks**: any number of stock accounts. Add stocks, log buys, sells, fees, dividends. Average cost, market value, profit/loss, history.
- **Expense** (was Monthly): years page (all-time totals, one card per year) > year page (balance, bars per month, vs previous year, balance curve with best/worst month, savings rate, spending by category, 12 month rows) > month page (vs last month, end-of-month forecast, day-by-day bars, biggest expenses, category breakdown with change, then the transactions with undo).
- Settings: currency, theme, dynamic colors, About.

## Stocks tab
- Update prices: one screen for all held stocks, oldest first, with % change; stale prices (7+ days) trigger a banner.
- Holdings: every stock across accounts, sorted by value, return or name, closed positions hidden by default. Switch to merge the same ticker held in several accounts. Weight of each holding in the portfolio.
- Portfolio value vs money invested over time (all stocks on the Holdings tab, per account on the account page), best and worst performer, total fees paid.

- Dividends screen: last 12 months, projected yearly dividends (last 12 months from stocks still held), yield on cost and on value, bars per month, totals by year and by stock. Dividend entry accepts a per-share amount and multiplies by the shares held on that date (you can still type the total).

- Realized gains (Stocks tab): every sale with its profit or loss, totals and fees by year, closed positions, CSV export of trades and dividends (all years or one year).
- Stock splits: add a split on the stock page; quantities, average price, charts and values adjust automatically (your entered trades are never changed). Selling checks the shares held on the sale date.
- Per stock: sector or tag (sector chart on Holdings), note, target price and stop price with an alert when a saved price reaches them and a banner on the Stocks tab.
- Room schema v5 (table stock_splits, four new stock columns), migration 4 to 5; all part of backups.

- Stocks tab is one scrolling page: hero card (value, return, trend line, quick tiles Prices / Dividends / Gains / Lists), then Accounts or Holdings. The ＋ Stock button adds a stock directly.
- Pick-or-add lists: brokers, account names and stocks come from lists with a "＋ Add new…" entry in the picker, so nothing is retyped. Manage them from the Lists tile. Existing accounts and stocks fill the lists automatically (migration 5 to 6). The lists only feed pickers; accounts and stocks keep their own text.

## Price history
Every price you enter for a stock, and every trade price, is saved as a point (one per stock per day). The net worth chart uses the latest recorded price before each month end (cost if none) and each stock page shows its price chart. The migration 3 to 4 fills the history from your existing trades and last prices. Points are evenly spaced on the chart. Part of backups.

## Budgets
A monthly limit per expense category (Expense tab > Budgets, or from a month page). Bars turn amber at 80% and red at 100%. Saving an expense that reaches 80% or 100% shows an alert. The Expense tab shows this month's budgets and alerts first. Limits are versioned by month: a change applies from the month shown onward and earlier months keep their old limit; 0 removes the budget from that month. Spending is matched by category id, so renaming keeps the budget. Budgets are part of backups (Room schema v3, migration 2 to 3). No system notifications yet.

## Categories
Expense tab shows every category (also with 0) with its total per year, expense and income, and a table of all years. "Add, rename or delete categories" opens Manage on the Expense tab. Renaming offers "Also update past transactions" (on by default). Deleting keeps old transactions under their saved name. New transactions from a month page start in that month.

## Architecture (step 1 of 2)
- `StocksRepository` (data layer, one instance per process) owns brokers, stocks, trades, dividends, prices, splits and the pick lists with their rules (split adjustment, price history, price alerts).
- `StocksViewModel` serves every stock screen. `MainViewModel` keeps expenses, budgets, banks, backup and import, and only reads stock data for the Overview pages (moved in step 2).
- `SettingsStore` and `BackupManager` are shared singletons (`get(context)`), so all view models see the same settings.
- No behavior change in this version.

## Backup security
- Share: you choose a password; the file is encrypted with AES-256-GCM (key from PBKDF2-HMAC-SHA256, 600,000 iterations, random salt and IV). The header (appVersion, kdf, iterations) is readable and authenticated, so changing it makes decryption fail. A wrong password and a damaged file look the same on purpose.
- Sharing without a password is still possible (red button) and the import preview warns when a file is not encrypted.
- Automatic daily copies and the safety copy before Replace are encrypted with a key in the Android Keystore (no password). They stay on the phone and are lost on uninstall, so share a password-protected backup too. Copies made by older versions are encrypted on the next start.
- Files left in the share folder are deleted at each start and before each new share. CSV exports cannot be encrypted.
- A lost password cannot be recovered.

## Backup and restore
Settings > Backup: export and share (JSON, `A-Peak-backup-DATE.json`), import file, automatic daily copy on the phone (last 7, in app storage, lost on uninstall, so share one). Opening a backup from WhatsApp or a file manager starts the import preview. Overview shows a reminder after 14 days without sharing.
- File: `app`, `formatVersion`, `appVersion` (missing = 1.0.0), `author`, `exportedAt`, `settings`, one array per table. Ordered `Upgrades` hook in `BackupCodec.kt`. A backup from a newer app version is refused.
- Preview shows new / updated / unchanged per table. **Merge**: match by id, then by name (accounts, categories, banks, stock accounts, stocks by account+symbol); same id with different content = backup wins; children are re-pointed to the matched parent. Settings untouched. **Replace**: saves a safety copy, wipes all tables, restores everything including settings.

## Design
Navy, blue, gray and white palette (light and dark). Custom outline icons drawn in code (`ui/Icons.kt`), navy gradient hero cards, rounded tiles. Dynamic colors are OFF by default so the brand palette shows; switch on in Settings. Category and account icons are still user-chosen emoji.

## Rules
- Amounts are `Long` minor units (cents), prices too (2 decimals). Quantities are `Double`. UUID string ids.
- Stock cost uses the average-cost method. Fees raise cost on buys and reduce proceeds on sells.
- Market value uses the **last price you enter** per stock (no internet, no price feed).
- Single currency for the whole app.
- All UI text in `strings.xml`. Version from `BuildConfig`. Commit `app/schemas/`.

## Known limits
- Deleting a bank or stock account deletes its history (asks confirmation first).
- Status bar icon colour follows the system theme, not the in-app override.
- No Gradle wrapper jar: open in Android Studio and sync.

## Roadmap
1.1 backup/restore (all tables), 1.2 budgets, 1.3 statistics charts over time + tests, 1.4 recurring, 1.5 transfers, 1.6 search/CSV, 1.7 goals, 1.8 receipts, 1.9 lock + widget, 2.0 release.
